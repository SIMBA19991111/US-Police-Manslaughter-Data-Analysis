# Code of Conduct

Have a question, comment or concern about our data? We’d love to hear from you.

Note that all comments must adhere to the <a href="https://docs.github.com/en/site-policy/github-terms/github-community-code-of-conduct">GitHub Community Code of Conduct</a> as well as The Washington Post’s <a href="https://www.washingtonpost.com/discussions/2020/04/13/community-rules/">Community Rules</a>.

Comments in violation of these policies will be deleted, and the user subject to being blocked and reported to GitHub moderators.
